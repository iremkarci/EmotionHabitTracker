package com.example.emotionhabittracker.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import com.example.emotionhabittracker.data.entities.EntryEntity
import com.example.emotionhabittracker.data.entities.EntryHabitCrossRef
import com.example.emotionhabittracker.data.models.EntryWithHabits
import com.example.emotionhabittracker.data.models.HabitMoodStat

@Dao
interface EntryDao {

    @Insert
    suspend fun insertEntry(entry: EntryEntity): Long

    @Insert
    suspend fun insertCrossRefs(refs: List<EntryHabitCrossRef>)

    @Transaction
    @Query("SELECT * FROM entries ORDER BY dateEpochDay DESC")
    suspend fun getAllEntriesWithHabits(): List<EntryWithHabits>

    @Query("SELECT COUNT(*) FROM entries")
    suspend fun getTotalEntryCount(): Int

    @Query("SELECT mood FROM entries GROUP BY mood ORDER BY COUNT(*) DESC LIMIT 1")
    suspend fun getMostCommonMood(): String?

    @Query("""
        SELECT h.name AS habitName, COUNT(eh.habitId) AS count
        FROM entry_habit eh
        INNER JOIN habits h ON h.id = eh.habitId
        INNER JOIN entries e ON e.id = eh.entryId
        WHERE e.mood = :mood
        GROUP BY eh.habitId
        ORDER BY count DESC, habitName ASC
        LIMIT 10
    """)
    suspend fun getTopHabitsForMood(mood: String): List<HabitMoodStat>

    // DELETE - entry silme için
    @Query("DELETE FROM entry_habit WHERE entryId = :entryId")
    suspend fun deleteCrossRefsForEntry(entryId: Long)

    @Query("DELETE FROM entries WHERE id = :entryId")
    suspend fun deleteEntryById(entryId: Long)
}
