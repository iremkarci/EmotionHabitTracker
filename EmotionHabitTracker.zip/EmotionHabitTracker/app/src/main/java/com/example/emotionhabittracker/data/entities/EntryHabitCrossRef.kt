package com.example.emotionhabittracker.data.entities

import androidx.room.Entity

@Entity(
    tableName = "entry_habit",
    primaryKeys = ["entryId", "habitId"]
)
data class EntryHabitCrossRef(
    val entryId: Long,
    val habitId: Long
)
