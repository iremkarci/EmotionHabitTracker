package com.example.emotionhabittracker.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.emotionhabittracker.data.models.EntryWithHabits
import com.example.emotionhabittracker.databinding.ItemEntryBinding
import com.example.emotionhabittracker.ui.DateUtils

class EntriesAdapter(
    private var items: List<EntryWithHabits> = emptyList(),
    private val onDeleteClicked: (entryId: Long) -> Unit
) : RecyclerView.Adapter<EntriesAdapter.VH>() {

    class VH(val b: ItemEntryBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val dateText = DateUtils.formatEpochDay(item.entry.dateEpochDay)
        holder.b.tvEntryTitle.text = "$dateText • ${item.entry.mood}"

        holder.b.tvEntryHabits.text =
            if (item.habits.isEmpty()) "Habits: (none)"
            else "Habits: " + item.habits.joinToString(", ") { it.name }

        holder.b.btnDeleteEntry.setOnClickListener {
            onDeleteClicked(item.entry.id)
        }
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<EntryWithHabits>) {
        items = newItems
        notifyDataSetChanged()
    }
}
