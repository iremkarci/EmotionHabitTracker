package com.example.emotionhabittracker.data.models

data class HabitMoodStat(
    val habitName: String,
    val count: Int
)
