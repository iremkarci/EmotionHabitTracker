package com.example.emotionhabittracker.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.emotionhabittracker.data.dao.EntryDao
import com.example.emotionhabittracker.data.dao.HabitDao
import com.example.emotionhabittracker.data.entities.EntryEntity
import com.example.emotionhabittracker.data.entities.EntryHabitCrossRef
import com.example.emotionhabittracker.data.entities.HabitEntity

@Database(
    entities = [HabitEntity::class, EntryEntity::class, EntryHabitCrossRef::class],
    version = 1
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun habitDao(): HabitDao
    abstract fun entryDao(): EntryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val db = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "emotion_habit_db"
                ).build()
                INSTANCE = db
                db
            }
        }
    }
}
