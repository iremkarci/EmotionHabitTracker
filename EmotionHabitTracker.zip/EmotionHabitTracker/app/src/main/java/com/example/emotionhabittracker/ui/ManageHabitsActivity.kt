package com.example.emotionhabittracker.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.emotionhabittracker.data.db.AppDatabase
import com.example.emotionhabittracker.data.entities.HabitEntity
import com.example.emotionhabittracker.databinding.ActivityManageHabitsBinding
import com.example.emotionhabittracker.ui.adapters.HabitsAdapter
import kotlinx.coroutines.launch

class ManageHabitsActivity : AppCompatActivity() {

    private lateinit var b: ActivityManageHabitsBinding
    private val db by lazy { AppDatabase.getInstance(this) }
    private lateinit var adapter: HabitsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityManageHabitsBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = HabitsAdapter(onDelete = { habit ->
            lifecycleScope.launch {
                db.habitDao().deleteHabit(habit)
                loadHabits()
            }
        })

        b.rvHabits.layoutManager = LinearLayoutManager(this)
        b.rvHabits.adapter = adapter

        b.btnAddHabit.setOnClickListener {
            val name = b.etHabitName.text.toString().trim()
            if (name.length < 2) {
                Toast.makeText(this, "Habit adı çok kısa.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                db.habitDao().insertHabit(HabitEntity(name = name))
                b.etHabitName.setText("")
                loadHabits()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadHabits()
    }

    private fun loadHabits() {
        lifecycleScope.launch {
            val list = db.habitDao().getActiveHabits()
            adapter.submit(list)
        }
    }
}
