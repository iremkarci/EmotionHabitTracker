package com.example.emotionhabittracker.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AdapterView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.emotionhabittracker.data.db.AppDatabase
import com.example.emotionhabittracker.databinding.ActivityStatsBinding
import com.example.emotionhabittracker.ui.adapters.StatsAdapter
import kotlinx.coroutines.launch

class StatsActivity : AppCompatActivity() {

    private lateinit var b: ActivityStatsBinding
    private val db by lazy { AppDatabase.getInstance(this) }
    private val adapter = StatsAdapter()

    private val moods = listOf(
        "😊 Mutlu",
        "😌 Sakin",
        "😐 Nötr",
        "😓 Stresli",
        "😴 Yorgun",
        "😡 Sinirli",
        "😢 Üzgün"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityStatsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.rvStats.layoutManager = LinearLayoutManager(this)
        b.rvStats.adapter = adapter

        val moodAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, moods)
        b.spMood.adapter = moodAdapter

        b.spMood.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                loadStats(moods[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        loadStats(moods.first())
    }

    private fun loadStats(mood: String) {
        lifecycleScope.launch {
            val list = db.entryDao().getTopHabitsForMood(mood)
            adapter.submit(list)
        }
    }
}
