package com.example.emotionhabittracker.ui

import java.time.LocalDate
import java.time.format.DateTimeFormatter

object DateUtils {
    fun todayEpochDay(): Long = LocalDate.now().toEpochDay()

    fun formatEpochDay(epochDay: Long): String {
        val date = LocalDate.ofEpochDay(epochDay)
        return date.format(DateTimeFormatter.ISO_DATE)
    }
}
