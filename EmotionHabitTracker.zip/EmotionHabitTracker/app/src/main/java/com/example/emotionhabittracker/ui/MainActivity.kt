package com.example.emotionhabittracker.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.emotionhabittracker.R
import com.example.emotionhabittracker.data.db.AppDatabase
import com.example.emotionhabittracker.data.entities.EntryEntity
import com.example.emotionhabittracker.data.entities.EntryHabitCrossRef
import com.example.emotionhabittracker.data.entities.HabitEntity
import com.example.emotionhabittracker.databinding.ActivityMainBinding
import com.example.emotionhabittracker.ui.adapters.EntriesAdapter
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val db by lazy { AppDatabase.getInstance(this) }

    private val moods = listOf(
        "😊 Mutlu",
        "😌 Sakin",
        "😐 Nötr",
        "😓 Stresli",
        "😴 Yorgun",
        "😡 Sinirli",
        "😢 Üzgün"
    )

    private val entriesAdapter = EntriesAdapter(onDeleteClicked = { entryId ->
        AlertDialog.Builder(this)
            .setTitle("Silinsin mi?")
            .setMessage("Bu kaydı silmek istediğine emin misin?")
            .setPositiveButton("Sil") { _, _ ->
                lifecycleScope.launch {
                    db.entryDao().deleteCrossRefsForEntry(entryId)
                    db.entryDao().deleteEntryById(entryId)
                    refresh()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.rvEntries.layoutManager = LinearLayoutManager(this)
        b.rvEntries.adapter = entriesAdapter

        b.btnManageHabits.setOnClickListener {
            startActivity(Intent(this, ManageHabitsActivity::class.java))
        }

        b.btnStats.setOnClickListener {
            startActivity(Intent(this, StatsActivity::class.java))
        }

        b.fabAddEntry.setOnClickListener {
            openAddEntryDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            seedHabitsIfEmpty()

            val list = db.entryDao().getAllEntriesWithHabits()
            entriesAdapter.submit(list)

            val total = db.entryDao().getTotalEntryCount()
            val commonMood = db.entryDao().getMostCommonMood() ?: "—"
            b.tvSummary.text = "Toplam kayıt: $total\nEn sık mood: $commonMood"
        }
    }

    private suspend fun seedHabitsIfEmpty() {
        val habits = db.habitDao().getActiveHabits()
        if (habits.isNotEmpty()) return

        db.habitDao().insertHabit(HabitEntity(name = "Su içtim", category = "Health"))
        db.habitDao().insertHabit(HabitEntity(name = "Spor yaptım", category = "Fitness"))
        db.habitDao().insertHabit(HabitEntity(name = "Ders çalıştım", category = "Study"))
        db.habitDao().insertHabit(HabitEntity(name = "Meditasyon", category = "Mind"))
        db.habitDao().insertHabit(HabitEntity(name = "Yürüyüş", category = "Health"))
    }

    private fun openAddEntryDialog() {
        lifecycleScope.launch {
            val habits = db.habitDao().getActiveHabits()
            if (habits.isEmpty()) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("No habits")
                    .setMessage("Önce Habits ekranından alışkanlık ekle.")
                    .setPositiveButton("OK", null)
                    .show()
                return@launch
            }

            val dialogView = layoutInflater.inflate(R.layout.dialog_add_entry, null)

            val spMood = dialogView.findViewById<Spinner>(R.id.spMoodDialog)
            val container = dialogView.findViewById<LinearLayout>(R.id.habitsContainer)

            val moodAdapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                moods
            )
            spMood.adapter = moodAdapter
            spMood.setSelection(0)

            val checkBoxes = mutableListOf<CheckBox>()
            habits.forEach { habit ->
                val cb = CheckBox(this@MainActivity)
                cb.text = habit.name
                cb.textSize = 16f
                container.addView(cb)
                checkBoxes.add(cb)
            }

            AlertDialog.Builder(this@MainActivity)
                .setTitle("Bugün kaydı ekle")
                .setView(dialogView)
                .setPositiveButton("Kaydet") { _, _ ->
                    lifecycleScope.launch {
                        val selectedMood = spMood.selectedItem as String
                        val today = DateUtils.todayEpochDay()

                        val entryId = db.entryDao().insertEntry(
                            EntryEntity(dateEpochDay = today, mood = selectedMood)
                        )

                        val selectedHabitIds = habits
                            .filterIndexed { index, _ -> checkBoxes[index].isChecked }
                            .map { it.id }

                        val refs = selectedHabitIds.map { hid ->
                            EntryHabitCrossRef(entryId = entryId, habitId = hid)
                        }
                        db.entryDao().insertCrossRefs(refs)

                        refresh()
                    }
                }
                .setNegativeButton("İptal", null)
                .show()
        }
    }
}
