package com.example.emotionhabittracker.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.emotionhabittracker.data.entities.HabitEntity
import com.example.emotionhabittracker.databinding.ItemHabitBinding

class HabitsAdapter(
    private var items: List<HabitEntity> = emptyList(),
    private val onDelete: (HabitEntity) -> Unit
) : RecyclerView.Adapter<HabitsAdapter.VH>() {

    class VH(val b: ItemHabitBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemHabitBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val habit = items[position]
        holder.b.tvHabitName.text = habit.name
        holder.b.btnDeleteHabit.setOnClickListener { onDelete(habit) }
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<HabitEntity>) {
        items = newItems
        notifyDataSetChanged()
    }
}
