package com.example.emotionhabittracker.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.emotionhabittracker.data.entities.HabitEntity

@Dao
interface HabitDao {

    @Query("SELECT * FROM habits WHERE isActive = 1 ORDER BY name ASC")
    suspend fun getActiveHabits(): List<HabitEntity>

    @Insert
    suspend fun insertHabit(habit: HabitEntity): Long

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)
}
